#include "odp_api.h"
#include "aliases.h"
#include "backend.h"
#include "ctrl_plane_backend.h"
#include "dataplane.h"
#include <unistd.h>

//=   shared   ================================================================

extern __m128i val_eth[RTE_MAX_ETHPORTS];
extern struct rte_mempool * pktmbuf_pool[NB_SOCKETS];
extern struct rte_mempool *header_pool, *clone_pool;
extern struct lcore_conf lcore_conf[RTE_MAX_LCORE];

extern uint32_t enabled_port_mask;
int promiscuous_on = 0; /**< Ports set in promiscuous mode off by default. */
int numa_on = 1; /**< NUMA is enabled by default. */

#define MAX_LCORE_PARAMS 1024
struct lcore_params {
	uint8_t port_id;
	uint8_t queue_id;
	uint8_t lcore_id;
} __rte_cache_aligned;
struct lcore_params lcore_params_array[MAX_LCORE_PARAMS];
struct lcore_params lcore_params_array_default[];
struct lcore_params * lcore_params;
uint16_t nb_lcore_params;
struct lcore_params lcore_params_array[MAX_LCORE_PARAMS];
struct lcore_params lcore_params_array_default[] = {
	{0, 0, 2},
	{0, 1, 2},
	{0, 2, 2},
	{1, 0, 2},
	{1, 1, 2},
	{1, 2, 2},
	{2, 0, 2},
	{3, 0, 3},
	{3, 1, 3},
};

struct lcore_params * lcore_params = lcore_params_array_default;
uint16_t nb_lcore_params = sizeof(lcore_params_array_default) /
				sizeof(lcore_params_array_default[0]);

struct l2fwd_port_statistics port_statistics[RTE_MAX_ETHPORTS];

//=   used only here   ========================================================

struct lcore_queue_conf lcore_queue_conf[RTE_MAX_LCORE];

unsigned int rx_queue_per_lcore = 1;

#define MAX_JUMBO_PKT_LEN  9600

#define RTE_TEST_RX_DESC_DEFAULT 128
#define RTE_TEST_TX_DESC_DEFAULT 512
static uint16_t nb_rxd = RTE_TEST_RX_DESC_DEFAULT;
static uint16_t nb_txd = RTE_TEST_TX_DESC_DEFAULT;

static struct rte_eth_conf port_conf = {
	.rxmode = {
		.mq_mode = ETH_MQ_RX_RSS,
		.max_rx_pkt_len = ETHER_MAX_LEN,
		.split_hdr_size = 0,
		.header_split   = 0, /**< Header Split disabled */
		.hw_ip_checksum = 1, /**< IP checksum offload enabled */
		.hw_vlan_filter = 0, /**< VLAN filtering disabled */
		.jumbo_frame    = 0, /**< Jumbo Frame Support disabled */
		.hw_strip_crc   = 0, /**< CRC stripped by hardware */
	},
	.rx_adv_conf = {
		.rss_conf = {
			.rss_key = NULL,
			.rss_hf = ETH_RSS_IP,
		},
	},
	.txmode = {
		.mq_mode = ETH_MQ_TX_NONE,
	},
};

/* odp */
#define POOL_NUM_PKT 8192
#define POOL_SEG_LEN 1856
#define MAX_PKT_BURST 32

struct {
        odp_pktio_t if0, if1;
        odp_pktin_queue_t if0in, if1in;
        odp_pktout_queue_t if0out, if1out;
        odph_ethaddr_t src, dst;
} global;

//=============================================================================

#define UNUSED(x) (void)(x)

/* display usage */
static void
print_usage(const char *prgname)
{
	printf ("%s [EAL options] -- -p PORTMASK -P"
		"  [--config (port,queue,lcore)[,(port,queue,lcore]]"
		"  [--enable-jumbo [--max-pkt-len PKTLEN]]\n"
		"  -p PORTMASK: hexadecimal bitmask of ports to configure\n"
		"  -P : enable promiscuous mode\n"
		"  --config (port,queue,lcore): rx queues configuration\n"
		"  --no-numa: optional, disable numa awareness\n"
		"  --enable-jumbo: enable jumbo frame"
		" which max packet len is PKTLEN in decimal (64-9600)\n"
		"  --hash-entry-num: specify the hash entry number in hexadecimal to be setup\n",
		prgname);
}

static int parse_max_pkt_len(const char *pktlen)
{
	char *end = NULL;
	unsigned long len;

	/* parse decimal string */
	len = strtoul(pktlen, &end, 10);
	if ((pktlen[0] == '\0') || (end == NULL) || (*end != '\0'))
		return -1;

	if (len == 0)
		return -1;

	return len;
}

static int
parse_portmask(const char *portmask)
{
	char *end = NULL;
	unsigned long pm;

	/* parse hexadecimal string */
	pm = strtoul(portmask, &end, 16);
	if ((portmask[0] == '\0') || (end == NULL) || (*end != '\0'))
		return -1;

	if (pm == 0)
		return -1;

	return pm;
}

static int
parse_config(const char *q_arg)
{
	char s[256];
	const char *p, *p0 = q_arg;
	char *end;
	enum fieldnames {
		FLD_PORT = 0,
		FLD_QUEUE,
		FLD_LCORE,
		_NUM_FLD
	};
	unsigned long int_fld[_NUM_FLD];
	char *str_fld[_NUM_FLD];
	int i;
	unsigned size;

	nb_lcore_params = 0;

	while ((p = strchr(p0,'(')) != NULL) {
		++p;
		if((p0 = strchr(p,')')) == NULL)
			return -1;

		size = p0 - p;
		if(size >= sizeof(s))
			return -1;

		snprintf(s, sizeof(s), "%.*s", size, p);
		if (rte_strsplit(s, sizeof(s), str_fld, _NUM_FLD, ',') != _NUM_FLD)
			return -1;
		for (i = 0; i < _NUM_FLD; i++){
			errno = 0;
			int_fld[i] = strtoul(str_fld[i], &end, 0);
			if (errno != 0 || end == str_fld[i] || int_fld[i] > 255)
				return -1;
		}
		if (nb_lcore_params >= MAX_LCORE_PARAMS) {
			printf("exceeded max number of lcore params: %hu\n",
				nb_lcore_params);
			return -1;
		}
		lcore_params_array[nb_lcore_params].port_id = (uint8_t)int_fld[FLD_PORT];
		lcore_params_array[nb_lcore_params].queue_id = (uint8_t)int_fld[FLD_QUEUE];
		lcore_params_array[nb_lcore_params].lcore_id = (uint8_t)int_fld[FLD_LCORE];
		++nb_lcore_params;
	}
	lcore_params = lcore_params_array;
	return 0;
}

#define CMD_LINE_OPT_CONFIG "config"
#define CMD_LINE_OPT_NO_NUMA "no-numa"
#define CMD_LINE_OPT_ENABLE_JUMBO "enable-jumbo"
#define CMD_LINE_OPT_HASH_ENTRY_NUM "hash-entry-num"

/* Parse the argument given in the command line of the application */
static int
parse_args(int argc, char **argv)
{
	int opt, ret;
	char **argvopt;
	int option_index;
	char *prgname = argv[0];
	static struct option lgopts[] = {
		{CMD_LINE_OPT_CONFIG, 1, 0, 0},
		{CMD_LINE_OPT_NO_NUMA, 0, 0, 0},
		{CMD_LINE_OPT_ENABLE_JUMBO, 0, 0, 0},
		{CMD_LINE_OPT_HASH_ENTRY_NUM, 1, 0, 0},
		{NULL, 0, 0, 0}
	};

	argvopt = argv;

	while ((opt = getopt_long(argc, argvopt, "p:P",
				lgopts, &option_index)) != EOF) {

		switch (opt) {
		/* portmask */
		case 'p':
			enabled_port_mask = parse_portmask(optarg);
			if (enabled_port_mask == 0) {
				printf("invalid portmask\n");
				print_usage(prgname);
				return -1;
			}
			break;
		case 'P':
			printf("Promiscuous mode selected\n");
			promiscuous_on = 1;
			break;

		/* long options */
		case 0:
			if (!strncmp(lgopts[option_index].name, CMD_LINE_OPT_CONFIG,
				sizeof (CMD_LINE_OPT_CONFIG))) {
				ret = parse_config(optarg);
				if (ret) {
					printf("invalid config\n");
					print_usage(prgname);
					return -1;
				}
			}

			if (!strncmp(lgopts[option_index].name, CMD_LINE_OPT_NO_NUMA,
				sizeof(CMD_LINE_OPT_NO_NUMA))) {
				printf("numa is disabled \n");
				numa_on = 0;
			}

			if (!strncmp(lgopts[option_index].name, CMD_LINE_OPT_ENABLE_JUMBO,
				sizeof (CMD_LINE_OPT_ENABLE_JUMBO))) {
				struct option lenopts = {"max-pkt-len", required_argument, 0, 0};

				printf("jumbo frame is enabled - disabling simple TX path\n");
				port_conf.rxmode.jumbo_frame = 1;

				/* if no max-pkt-len set, use the default value ETHER_MAX_LEN */
				if (0 == getopt_long(argc, argvopt, "", &lenopts, &option_index)) {
					ret = parse_max_pkt_len(optarg);
					if ((ret < 64) || (ret > MAX_JUMBO_PKT_LEN)){
						printf("invalid packet length\n");
						print_usage(prgname);
						return -1;
					}
					port_conf.rxmode.max_rx_pkt_len = ret;
				}
				printf("set jumbo frame max packet length to %u\n",
						(unsigned int)port_conf.rxmode.max_rx_pkt_len);
			}
			break;

		default:
			print_usage(prgname);
			return -1;
		}
	}

	if (optind >= 0)
		argv[optind-1] = prgname;

	ret = optind-1;
	optind = 0; /* reset getopt lib */
	return ret;
}

static void
print_ethaddr(const char *name, const struct ether_addr *eth_addr)
{
	char buf[ETHER_ADDR_FMT_SIZE];
	ether_format_addr(buf, ETHER_ADDR_FMT_SIZE, eth_addr);
	printf("%s%s", name, buf);
}

static int
init_mem(unsigned nb_mbuf)
{
	unsigned lcore_id;
	char s[64];

	for (lcore_id = 0; lcore_id < RTE_MAX_LCORE; lcore_id++) {
		if (rte_lcore_is_enabled(lcore_id) == 0)
			continue;

		int socketid = get_socketid(lcore_id);

		if (socketid >= NB_SOCKETS) {
			rte_exit(EXIT_FAILURE, "Socket %d of lcore %u is out of range %d\n",
				socketid, lcore_id, NB_SOCKETS);
		}
		if (pktmbuf_pool[socketid] == NULL) {
			snprintf(s, sizeof(s), "mbuf_pool_%d", socketid);
			pktmbuf_pool[socketid] =
				rte_mempool_create(s, nb_mbuf, MBUF_SIZE, MEMPOOL_CACHE_SIZE,
					sizeof(struct rte_pktmbuf_pool_private),
					rte_pktmbuf_pool_init, NULL,
					rte_pktmbuf_init, NULL,
					socketid, 0);
			if (pktmbuf_pool[socketid] == NULL)
				rte_exit(EXIT_FAILURE,
						"Cannot init mbuf pool on socket %d\n", socketid);
			else
				printf("Allocated mbuf pool on socket %d\n", socketid);
		}
	}
	return 0;
}

/* TODO: move to other location */
extern odph_table_ops_t odph_hash_table_ops;

int init_lookup_tables()
{

  odph_table_t table;
  odph_table_ops_t *test_ops;
  printf("Initializing tables...\n");

	printf("test hash table:\n");
	test_ops = &odph_hash_table_ops;

	table = test_ops->f_create("test", 2, 4, 16);
	if (table == NULL) {
	printf("table create fail\n");
	return -1;
	}

    printf("Initializing tables Done.\n");
	return 0;
}

#define CHANGE_TABLE(fun, par...) \
{ \
    int current_replica = active_replica[socketid][tableid]; \
    int next_replica = (current_replica+1)%NB_REPLICA; \
    fun(tables_on_sockets[socketid][tableid][next_replica], par); \
    change_replica(socketid, tableid, next_replica); \
    usleep(TABCHANGE_DELAY); \
    for(current_replica = 0; current_replica < NB_REPLICA; current_replica++) \
        if(current_replica != next_replica) fun(tables_on_sockets[socketid][tableid][current_replica], par); \
}

#define FORALLNUMANODES(b) \
    int socketid; \
    for(socketid = 0; socketid < NB_SOCKETS; socketid++) \
        if(tables_on_sockets[socketid][0][0] != NULL) \
            b
void
exact_add_promote(int tableid, uint8_t* key, uint8_t* value) {
    FORALLNUMANODES(CHANGE_TABLE(exact_add, key, value))
}
void
lpm_add_promote(int tableid, uint8_t* key, uint8_t depth, uint8_t* value) {
    FORALLNUMANODES(CHANGE_TABLE(lpm_add, key, depth, value))
}
void
ternary_add_promote(int tableid, uint8_t* key, uint8_t* mask, uint8_t* value) {
    FORALLNUMANODES(CHANGE_TABLE(ternary_add, key, mask, value))
}
void
table_setdefault_promote(int tableid, uint8_t* value) {
    FORALLNUMANODES(CHANGE_TABLE(table_setdefault, value))
}

static odp_pktio_t create_pktio(const char *name, odp_pool_t pool,
                                odp_pktin_queue_t *pktin,
                                odp_pktout_queue_t *pktout)
{
        odp_pktio_param_t pktio_param;
        odp_pktin_queue_param_t in_queue_param;
        odp_pktout_queue_param_t out_queue_param;
        odp_pktio_t pktio;

        odp_pktio_param_init(&pktio_param);

        pktio = odp_pktio_open(name, pool, &pktio_param);
        if (pktio == ODP_PKTIO_INVALID) {
                printf("Failed to open %s\n", name);
                exit(1);
        }

        odp_pktin_queue_param_init(&in_queue_param);
        odp_pktout_queue_param_init(&out_queue_param);

        in_queue_param.op_mode = ODP_PKTIO_OP_MT_UNSAFE;

        if (odp_pktin_queue_config(pktio, &in_queue_param)) {
                printf("Failed to config input queue for %s\n", name);
                exit(1);
        }

        out_queue_param.op_mode = ODP_PKTIO_OP_MT_UNSAFE;

        if (odp_pktout_queue_config(pktio, &out_queue_param)) {
                printf("Failed to config output queue for %s\n", name);
                exit(1);
        }

        if (odp_pktin_queue(pktio, pktin, 1) != 1) {
                printf("pktin queue query failed for %s\n", name);
                exit(1);
        }
        if (odp_pktout_queue(pktio, pktout, 1) != 1) {
                printf("pktout queue query failed for %s\n", name);
                exit(1);
        }
        return pktio;
}

uint8_t
odp_initialize(int argc, char **argv)
{

        odp_pool_t pool;
        odp_pool_param_t params;
        odp_cpumask_t cpumask;
        odph_linux_pthread_t thd;

	/* init ODP */
        if (odp_init_global(NULL, NULL)) {
                printf("Error: ODP global init failed.\n");
                exit(1);
        }

        if (odp_init_local(ODP_THREAD_CONTROL)) {
                printf("Error: ODP local init failed.\n");
                exit(1);
        }

	/* create the packet pool */
        odp_pool_param_init(&params);
        params.pkt.seg_len = POOL_SEG_LEN;
        params.pkt.len     = POOL_SEG_LEN;
        params.pkt.num     = POOL_NUM_PKT;
        params.type        = ODP_POOL_PACKET;

        pool = odp_pool_create("packet pool", &params);

        if (pool == ODP_POOL_INVALID) {
                printf("Error: packet pool create failed.\n");
                exit(1);
        }	
	
	/* initialize ports */
	nb_ports = 2;

        global.if0 = create_pktio(argv[1], pool, &global.if0in, &global.if0out);
        global.if1 = create_pktio(argv[2], pool, &global.if1in, &global.if1out);	

/* ToDo dpdk */
/* check if similar thing on ODP */
//	check_all_ports_link_status(nb_ports, enabled_port_mask);
/* for now only exact table is possible on ODP-hash table */
	init_lookup_tables();
/* dpdk */	


/* initiate control plane */
	init_control_plane();

        odp_cpumask_default_worker(&cpumask, 1);
        odph_linux_pthread_create(&thd, &cpumask, run_worker, NULL,
                                  ODP_THREAD_WORKER);
        odph_linux_pthread_join(&thd, 1);

	return nb_ports;
}

